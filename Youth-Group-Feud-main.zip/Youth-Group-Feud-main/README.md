# Youth-Group-Feud
Needs a bunch of Audio files for to read out the questions

I used Eleven Labs to make them

Also needs a json file with data in it to make the questions and stuff

I also created a survey thing to make the json files, https://github.com/nbgit41/Youth-Group-Feud-Survey

points in question.json refers to the number of users that answered that answer
